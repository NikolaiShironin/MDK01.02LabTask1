﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SolveFormula
{
    public class Solve
    {
        public double FormulaS(double x)
        {
            double S = 1 + x + Math.Pow(x, 2) / 2 + Math.Pow(x, 3) / 3 + Math.Pow(x, 4) / 4;
            return S;
        }
        public double FormulaA(double X, double Y)
        {
            double A = X * (Math.Sin(Math.Pow(X, 3) + Math.Pow(Math.Cos(Y), 2)));
            return A;
        }
    }
}
