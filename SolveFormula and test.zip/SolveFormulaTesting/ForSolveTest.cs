﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using SolveFormula;

namespace SolveFormulaTesting
{
    [TestClass]
    public class ForSolveTest
    {
        Solve Fs = new Solve();

        [TestMethod]
        public void SolveTestForS_x_raven_2tochka1_Result13tochla254025()
        {
            double x = 2.1;
            double expected_S = 13.254025;
            double actual_S = Fs.FormulaS(x);
            Assert.AreEqual(expected_S, actual_S);
        }
        [TestMethod]
        public void SolveTestForS_x_raven_minus3_Result13tochla75()
        {
            double x = -3;
            double expected_S = 13.75;
            double actual_S = Fs.FormulaS(x);
            Assert.AreEqual(expected_S, actual_S);
        }
        [TestMethod]
        public void SolveTestForS_x_raven_0_Result1()
        {
            double x = 0;
            double expected_S = 1;
            double actual_S = Fs.FormulaS(x);
            Assert.AreEqual(expected_S, actual_S);
        }
        [TestMethod]
        public void SolveTestForS_x_raven_10_Result37tochka75()
        {
            double x = 3;
            double expected_S = 37.75;
            double actual_S = Fs.FormulaS(x);
            Assert.AreEqual(expected_S, actual_S);
        }
        [TestMethod]
        public void SolveTestForS_x_raven_90_Result16649641()
        {
            double x = 90;
            double expected_S = 16649641;
            double actual_S = Fs.FormulaS(x);
            Assert.AreEqual(expected_S, actual_S);
        }
        [TestMethod]
        public void SolveTestForA_X_raven_0_and_Y_raven_0_Result0()
        {
            double X = 0;
            double Y = 0;
            double expected_S = 0;
            double actual_S = Fs.FormulaA(X , Y);
            Assert.AreEqual(expected_S, actual_S);
        }
        [TestMethod]
        public void SolveTestForA_X_raven_MINUS1_and_Y_raven_0_Result0()
        {
            double X = -1;
            double Y = 0;
            double expected_S = 0;
            double actual_S = Fs.FormulaA(X, Y);
            Assert.AreEqual(expected_S, actual_S);
        }
        [TestMethod]
        public void SolveTestForA_X_raven_6_and_Y_raven_5_Result3tochka816579544207()
        {
            double X = 6;
            double Y = 5;       
            double expected_S = 3.816579544207;
            double actual_S = Fs.FormulaA(X, Y);
            Assert.AreEqual(expected_S, actual_S);
        }
        [TestMethod]
        public void SolveTestForA_X_raven_0_and_Y_raven_9tochka9_Result0()
        {
            double X = 0;
            double Y = 9.9;
            double expected_S = 0;
            double actual_S = Fs.FormulaA(X, Y);
            Assert.AreEqual(expected_S, actual_S);
        }
        [TestMethod]
        public void SolveTestFo3rA_X_raven_0_and_Y_raven_24335_Result0()
        {
            double X = 0;
            double Y = 24335;
            double expected_S = 0;
            double actual_S = Fs.FormulaA(X, Y);
            Assert.AreEqual(expected_S, actual_S);
        }
    }
}
